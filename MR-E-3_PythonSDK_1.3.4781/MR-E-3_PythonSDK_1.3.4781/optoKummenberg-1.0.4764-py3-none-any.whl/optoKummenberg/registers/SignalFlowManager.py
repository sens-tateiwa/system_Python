from .ClassAbstracts import System
from ..tools.systems_registers_tools import is_valid_channel
from ..tools.systems_registers_tools import get_registers
from optoKummenberg.tools.definitions import *
from warnings import warn
import struct
from enum import Enum

class SignalFlowManager(System):
    r"""
The Signal Flow Manager is managing the active systems in the signal flow chain.
Advanced manager System ID for channel X: 0x41

+---------------------+---------------+-------------+----------+--------------+---------------+--------------------+
| Register Name       | Id            | Type        | Unit     | Range        | Default       | Comment            |
+=====================+================+=============+==========+==============+===============+====================+
| input               | 5x CHANNEL + 0 | uint 32-bit | SystemID | 0x48 to 0x7f |               |                    |
+---------------------+----------------+-------------+----------+--------------+---------------+--------------------+
| input_conditioning  | 5x CHANNEL + 1 | uint 32-bit | SystemID | 0x48 to 0x7f |               |                    |
+---------------------+----------------+-------------+----------+--------------+---------------+--------------------+
| control             | 5x CHANNEL + 2 | uint 32-bit | SystemID | 0x48 to 0x7f |               |                    |
+---------------------+----------------+-------------+----------+--------------+---------------+--------------------+
| output_conditioning | 5x CHANNEL + 3 | uint 32-bit | SystemID | 0x48 to 0x7f |               |                    |
+---------------------+----------------+-------------+----------+--------------+---------------+--------------------+
| output              | 5x CHANNEL + 4 | uint 32-bit | SystemID | 0x48 to 0x7f |               |                    |
+---------------------+----------------+-------------+----------+--------------+---------------+--------------------+

    """

    @staticmethod
    def help():
        print(SignalFlowManager.__doc__)

    def __init__(self, board=None):
        self.sys_id = 0x40
        self.PATH_OFFSET = 20
        self.CHANNEL_OFFSET = 5
        self.CONFIG_OUTPUT_REG_NBR = 12
        self.STAGE_REG_NBR = 60
        self._readonly = False

        # 60 stage registers in total. Id in range 0-59
        # 0-19 main flow path registers (4x channel mul 5x stages)
        # 20-39 feed forward path registers (4x channel mul 5x stages)
        # 40-59 feed back path registers (4x channel mul 5x stages)
        self.stageRegister = {'name': 'stageRegister',
                        'id': self.sys_id << 8 | 0x00,
                        'type': int,
                        'unit': 'int',
                        'range': [0x00, 0xFF],
                        'default': None,
                        'value': None}

        # define "list" of registers of certain number - name approach
        for reg_index in range(self.STAGE_REG_NBR):
            self.__dict__['stageRegister_' + str('{0:02d}'.format(reg_index))] = {
                        'name': 'stageRegister_'+str(reg_index),
                        'id': self.sys_id << 8 | 60 + reg_index,
                        'type': float,
                        'unit': None,
                        'range': None,
                        'default': None,
                        'value': None}

        # 12 stage output registers Id range 60-71 - index approach
        self.configOutput = {'name': 'configOutput',
                       'id': self.sys_id << 8 | 60,
                       'type': int,
                       'unit': 'SystemID',
                       'range': None,
                       'default': None,
                       'value': None}

        # define "list" of registers of certain number - name approach
        for reg_index in range(self.CONFIG_OUTPUT_REG_NBR):
            self.__dict__['configOutput_' + str('{0:02d}'.format(reg_index))] = {
                        'name': 'configOutput_'+str(reg_index),
                        'id': self.sys_id << 8 | 60 + reg_index,
                        'type': float,
                        'unit': None,
                        'range': None,
                        'default': None,
                        'value': None}

        self.mainToForward = {'name': 'mainToForward',
                       'id': self.sys_id << 8 | 72,
                       'type': int,
                       'unit': int,
                       'range': None,
                       'default': None,
                       'value': None}

        self.feedForward = {'name': 'feedForward',
                       'id': self.sys_id << 8 | 73,
                       'type': int,
                       'unit': int,
                       'range': None,
                       'default': None,
                       'value': None}

        self.feedBack = {'name': 'feedBack',
                       'id': self.sys_id << 8 | 75,
                       'type': int,
                       'unit': None,
                       'range': None,
                       'default': None,
                       'value': None}

        self.defaultSignalFlow = {'name': 'defaultSignalFlow',
                       'id': self.sys_id << 8 | 79,
                       'type': int,
                       'unit': None,
                       'range': None,
                       'default': None,
                       'value': None}

        self.stageOutput = {'name': 'stageOutput',
                       'id': self.sys_id << 8 | 80,
                       'type': float,
                       'unit': None,
                       'range': None,
                       'default': None,
                       'value': None}

        # define "list" of registers of certain number
        for reg_index in range(self.STAGE_REG_NBR):
            self.__dict__['stageOutput_' + str('{0:02d}'.format(reg_index))] = {
                        'name': 'stageOutput_'+str(reg_index),
                        'id': self.sys_id << 8 | 80 + reg_index,
                        'type': float,
                        'unit': None,
                        'range': None,
                        'default': None,
                        'value': None}

        System.__init__(self, board=board)
        self.name = self.__class__.__name__

    ## Sets the system on the specific stage. (input stage, input conditiong stage, control stage, output conditioning
    # stage, output stage)
    def SetStageSystem(self, path_id, stage_id, channel_id, system_id):
        if path_id < EnSignalFlowPath.PATH_NBR:
            # calculate register id from parameters
            regId = self.CHANNEL_OFFSET * channel_id + self.PATH_OFFSET * path_id + stage_id
            stage_address = self.stageRegister['id'] + regId
            return self.set_register_id(stage_address, system_id)
        else:
            warn("Stage register index out of limit", RuntimeWarning)

    ## Gets the system on the specific stage. (input stage, input conditiong stage, control stage, output conditioning
    # stage, output stage)
    def GetStageSystem(self, path_id, stage_id, channel_id):
        if path_id < EnSignalFlowPath.PATH_NBR and stage_id < self.CHANNEL_OFFSET:
            regId = self.CHANNEL_OFFSET * channel_id + self.PATH_OFFSET * path_id + stage_id
            stage_address = self.stageRegister['id'] + regId
            return self.get_register_id(stage_address)
        else:
            warn("Stage register index out of limit", RuntimeWarning)

    ## Gets stage output.
    def GetStageOutput(self, path_id, stage_id, channel_id):
        response = []
        regid = self.GetStageOutputRegisterID(path_id, stage_id, channel_id)
        if regid is not None:
            raw_data = self.get_register_id(regid)
            response.append(struct.unpack(ENDIAN + 'f', bytes(raw_data))[0])
            return response[0]

    ## Gets stage output register ID.
    def GetStageOutputRegisterID(self, path_id, stage_id, channel_id):
        if stage_id >= self.CHANNEL_OFFSET or path_id >= EnSignalFlowPath.PATH_NBR:
            warn("index out of limit", RuntimeWarning)
            return
        register_idx = self.CHANNEL_OFFSET * channel_id + self.PATH_OFFSET * path_id + stage_id
        if register_idx < self.STAGE_REG_NBR:
            return self.stageOutput['id'] + register_idx
        else:
            warn("Stage output index out of limit", RuntimeWarning)

    ## Sets main to forward connection, channel_mask zero bit resets connection for particular channel
    def SetMainToForwardConnection(self, channel_mask=0x0F):
        if channel_mask <= 0x0F:
            return self.set_register('mainToForward', channel_mask)
        else:
            warn("Unresolved feedback connection setup", RuntimeWarning)

    ## Sets the default signal flow
    def SetDefaultSignalFlow(self):
        return self.set_register('defaultSignalFlow', 0)

    ## Sets feed forward conection
    # register index: 0 - output conditioning stage, 1 - output stage
    # channel_mask zero bit resets connection for particular channel
    def SetFeedForwardConnection(self, register_idx, channel_mask):
        if register_idx <= 1 and channel_mask <= 0x0F:
            return self.set_register_id(self.feedForward['id'] + register_idx, channel_mask)
        else:
            warn("unresolved feed forward connection setup", RuntimeWarning)

    ## Sets feedback conection
    # channel_mask zero bit resets connection for particular channel
    def SetFeedBackConnection(self, channel_mask):
        if channel_mask <= 0x0F:
            return self.set_register('feedBack', channel_mask)
        else:
            warn("Unresolved feedback connection setup", RuntimeWarning)



