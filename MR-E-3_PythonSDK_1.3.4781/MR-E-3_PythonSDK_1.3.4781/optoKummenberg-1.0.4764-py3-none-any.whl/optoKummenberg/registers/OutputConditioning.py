from .ClassAbstracts import System
from ..tools.systems_registers_tools import is_valid_channel
from ..tools.definitions import CHUNK_SIZE

class OutputConditioning(System):
    r"""
Output Conditioning Channel - Offset and Scaling
System ID: 0xD0 through 0xdF

+---------------------+------+-------------+--------------------+-------------+---------+------------------------+
| Register Name       | Id   | Type        | Unit               | Range       | Default | Comment                |
+=====================+======+=============+====================+=============+=========+========================+
|                     |      |             |                    |             |         |                        |
+---------------------+------+-------------+--------------------+-------------+---------+------------------------+
    """

    # TODO: Not implemented yet in firmware
    @staticmethod
    def help():
        print(OutputConditioning.__doc__)

    def __init__(self, channel: int = 0, board=None):
        self.sys_id = 0xD0 | channel
        self._readonly = False

        self.gain = {'id': self.sys_id << 8 | 0x00,
                     'type': float,
                     'unit': None,
                     'range': None,
                     'default': 0,
                     'value': 0}
        self.offset = {'id': self.sys_id << 8 | 0x01,
                       'type': bool,
                       'unit': None,
                       'range': None,
                       'default': 1,
                       'value': 1}
        System.__init__(self, channel, board)
        self.name = self.__class__.__name__
        if not is_valid_channel(self._channel):
            raise ValueError('Channel Range Error')

class OutputConditioningFilter(System):
    r"""
Output Conditioning Channel - Offset and Scaling
System ID: 0xD8 through 0xDF

+---------------------+------+-------------+--------------------+-------------+---------+------------------------+
| Register Name       | Id   | Type        | Unit               | Range       | Default | Comment                |
+=====================+======+=============+====================+=============+=========+========================+
|                     |      |             |                    |             |         |                        |
+---------------------+------+-------------+--------------------+-------------+---------+------------------------+
    """

    @staticmethod
    def help():
        print(OutputConditioningFilter.__doc__)

    def __init__(self, channel: int = 0, board=None):
        self.sys_id = 0xD8 | channel
        self._readonly = False
        self.mskActiveFilters = {'id': self.sys_id << 8 | 0x00,
                     'type': int,
                     'unit': None,
                     'range': [0, 15],
                     'default': 1,
                     'value': 1}
        self.selectFilterInstance = {'id': self.sys_id << 8 | 0x01,
                       'type': int,
                       'unit': None,
                       'range': [0, 3],
                       'default': 0,
                       'value': 0}
        self.loadFilterCoeff = {'id': self.sys_id << 8 | 0x02,
                       'type':int,
                       'unit': None,
                       'range': [0, 1],
                       'default': 0,
                       'value': 0}
        self.getInCoeffNbr = {'id': self.sys_id << 8 | 0x03,
                       'type':int,
                       'unit': None,
                       'range': [0, 100],
                       'default': 0,
                       'value': 0}
        self.getOutCoeffNbr = {'id': self.sys_id << 8 | 0x04,
                       'type':int,
                       'unit': None,
                       'range': [0, 100],
                       'default': 0,
                       'value': 0}
        self.inputValue = {'id': self.sys_id << 8 | 0x10,
                       'type':float,
                       'unit': None,
                       'range': None,
                       'default': 0.0,
                       'value': 0.0}
        self.outputValue = {'id': self.sys_id << 8 | 0x20,
                       'type':float,
                       'unit': None,
                       'range': None,
                       'default': 0.0,
                       'value': 0.0}
        self.outputValueF0 = {'id': self.sys_id << 8 | 0x21,
                       'type':float,
                       'unit': None,
                       'range': None,
                       'default': 0.0,
                       'value': 0.0}
        self.outputValueF1 = {'id': self.sys_id << 8 | 0x22,
                       'type':float,
                       'unit': None,
                       'range': None,
                       'default': 0.0,
                       'value': 0.0}
        self.outputValueF2 = {'id': self.sys_id << 8 | 0x23,
                       'type':float,
                       'unit': None,
                       'range': None,
                       'default': 0.0,
                       'value': 0.0}
        self.outputValueF3 = {'id': self.sys_id << 8 | 0x24,
                       'type':float,
                       'unit': None,
                       'range': None,
                       'default': 0.0,
                       'value': 0.0}

        self.vectInputCoeff = {'id': self.sys_id << 8 | 0x00,
                               'type': float}

        self.vectOutputCoeff = {'id': self.sys_id << 8 | 0x01,
                               'type': float}

        System.__init__(self, channel, board)
        self.name = self.__class__.__name__
        if not is_valid_channel(self._channel):
            raise ValueError('Channel Range Error')

    def SetActiveFiltersMask(self, value):
        return self.set_register('mskActiveFilters', value)

    def GetActiveFiltersMask(self):
        return self.get_register('mskActiveFilters')

    def SelectFilterInstance(self, value):
        return self.set_register('selectFilterInstance', value)

    def LoadFilterCoeff(self, value):
        return self.set_register('loadFilterCoeff', value)

    def GetFilterInputCoeffNum(self):
        return self.get_register('getInCoeffNbr')

    def GetFilterOutputCoeffNum(self):
        return self.get_register('getOutCoeffNbr')

    def GetFilterInput(self):
        return self.get_register('inputValue')

    def GetFilterOutput(self):
        return self.get_register('outputValue')

    def GetOutputValueID(self, instance_number):
        if instance_number == 0:
            return self.outputValueF0['id']
        elif instance_number == 1:
            return self.outputValueF1['id']
        elif instance_number == 2:
            return self.outputValueF2['id']
        elif instance_number == 3:
            return self.outputValueF3['id']

    def SetInputCoeffs(self, index, vector):
        iters = len(vector) // CHUNK_SIZE
        remainder = len(vector) % CHUNK_SIZE
        # split vector to data packets
        for i in range(iters):
            aux = vector[i * CHUNK_SIZE: (i+1) * CHUNK_SIZE]
            result = self._board.set_vector(self.vectInputCoeff, index + i * CHUNK_SIZE, aux)
        if remainder:
            aux = vector[iters * CHUNK_SIZE: len(vector)]
            result = self._board.set_vector(self.vectInputCoeff, index + iters * CHUNK_SIZE, aux)
        return result

    def SetOutputCoeffs(self, index, vector):
        iters = len(vector) // CHUNK_SIZE
        remainder = len(vector) % CHUNK_SIZE
        # split vector to data packets
        for i in range(iters):
            aux = vector[i * CHUNK_SIZE: (i+1) * CHUNK_SIZE]
            result = self._board.set_vector(self.vectOutputCoeff, index + i * CHUNK_SIZE, aux)
        if remainder:
            aux = vector[iters * CHUNK_SIZE: len(vector)]
            result = self._board.set_vector(self.vectOutputCoeff, index + iters * CHUNK_SIZE, aux)
        return result

    def GetInputCoeffs(self, index, count):
        vec = []
        # end_index = index + count
        iters = count // CHUNK_SIZE
        remainder = count % CHUNK_SIZE
        for i in range(iters):
            aux = self._board.get_vector(self.vectInputCoeff, i * CHUNK_SIZE, CHUNK_SIZE)
            vec.extend(aux)
        if remainder:
            aux = self._board.get_vector(self.vectInputCoeff, iters * CHUNK_SIZE, remainder)
            vec.extend(aux)
        return vec


    def GetOutputCoeffs(self, index, count):
        vec = []
        # end_index = index + count
        iters = count // CHUNK_SIZE
        remainder = count % CHUNK_SIZE
        for i in range(iters):
            aux = self._board.get_vector(self.vectOutputCoeff, i * CHUNK_SIZE, CHUNK_SIZE)
            vec.extend(aux)
        if remainder:
            aux = self._board.get_vector(self.vectOutputCoeff, iters * CHUNK_SIZE, remainder)
            vec.extend(aux)
        return vec
